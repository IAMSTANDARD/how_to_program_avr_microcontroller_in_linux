#/bin/sh
export MFILE_HOME=.
cd ~/bin/mfile
./mfile.tcl
