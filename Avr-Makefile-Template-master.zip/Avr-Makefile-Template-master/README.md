Avr-Makefile-Template
=====================

avr-GCC makefile Template